package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R

@Composable
fun IrasScreen(
    viewModel: IrasViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // Runtime Permission Request
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
            viewModel.startListening()
        }
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            permissionsLauncher.launch(needed.toTypedArray())
        } else {
            viewModel.startListening()
        }
    }

    val neonCyan = Color(0xFF00F0FF)
    val neonMagenta = Color(0xFFFF007F)
    val neonDarkBg = Color(0xFF070B14)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(neonDarkBg)
    ) {
        // Futuristic Cyberpunk Wallpaper Overlay
        Image(
            painter = painterResource(id = R.drawable.cyberpunk_bg),
            contentDescription = "Cyberpunk Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            alpha = 0.35f
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Cyberpunk Top HUD Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x990A0F1D))
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(neonCyan, neonMagenta)),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "IRAS • অলটিমেট",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Gemini 3.7 Flash Engine",
                        color = neonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (uiState.isListening) neonCyan else neonMagenta)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (uiState.isListening) "LISTENING" else "STANDBY",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mood Selector Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(
                    listOf(
                        Triple("😊 খুশি", IrasMood.HAPPY, neonCyan),
                        Triple("🥺 দুঃখী", IrasMood.SAD, Color(0xFF00C2FF)),
                        Triple("😤 রাগি", IrasMood.ANGRY, neonMagenta),
                        Triple("⚡ নরমাল", IrasMood.NEUTRAL, Color(0xFFFFD700))
                    )
                ) { (label, mood, color) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (uiState.mood == mood) color.copy(alpha = 0.25f) else Color(0x6610172A))
                            .border(
                                width = 1.dp,
                                color = if (uiState.mood == mood) color else Color(0x33FFFFFF),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { viewModel.setManualMood(mood) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (uiState.mood == mood) color else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3D Animated Female Avatar (IRAS)
            Iras3DAvatar(
                mood = uiState.mood,
                isSpeaking = uiState.isSpeaking,
                isListening = uiState.isListening,
                audioRms = uiState.audioRms,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Holographic Speech Bubble / Subtitle Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xCC0D1B2A)),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    Brush.horizontalGradient(listOf(neonCyan.copy(alpha = 0.5f), neonMagenta.copy(alpha = 0.5f)))
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = neonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (uiState.transcript.isNotBlank()) "আপনি বলেছেন: \"${uiState.transcript}\"" else "IRAS Voice Response",
                            color = neonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = uiState.lastSpokenText,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Orbital Microphone Button (Universe Orbiting Mic)
            OrbitalMicButton(
                isListening = uiState.isListening,
                audioRms = uiState.audioRms,
                onClick = { viewModel.toggleListening() }
            )

            Text(
                text = if (uiState.isListening) "ভয়েস কমান্ড বলুন..." else "মাইক্রোফোনে ট্যাপ করুন বা 'ভাইরাস'/'IRAS' বলুন",
                color = if (uiState.isListening) neonCyan else Color(0xFF94A3B8),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 6.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Quick Voice Command Badges (For Touch or Voice Testing)
            Text(
                text = "⚡ জনপ্রিয় ভয়েস কমান্ড",
                color = neonMagenta,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                val commandList = listOf(
                    "🔦 টর্চ অন" to "টর্চ অন",
                    "🔦 টর্চ অফ" to "টর্চ অফ",
                    "🏠 হোমে যাও" to "হোমে যাও",
                    "📸 স্ক্রিনশট নাও" to "স্ক্রিনশট",
                    "🔒 স্ক্রিন লক" to "স্ক্রিন লক",
                    "📞 বাবাকে কল" to "বাবাকে ফোন লাগা",
                    "🔔 নোটিফিকেশন" to "নোটিফিকেশন দেখাও",
                    "⚙️ কুইক সেটিংস" to "কুইক সেটিংস",
                    "♿ এক্সেসিবিলিটি" to "এক্সেসিবিলিটি",
                    "🎵 গান বাজা" to "পাল রুকা গান বাজা",
                    "📱 ফ্রিফায়ার ম্যাক্স" to "ফ্রিফায়ার ম্যাক্স খোল",
                    "🔋 ব্যাটারি স্ট্যাটাস" to "ব্যাটারি কেমন?",
                    "🆘 SOS হেল্প" to "হেল্প",
                    "🌡️ সিস্টেম ও সেন্সর" to "ফোনের তাপমাত্রা কেমন"
                )
                items(commandList) { (label, command) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x9910172A))
                            .border(1.dp, Color(0x4400F0FF), RoundedCornerShape(12.dp))
                            .clickable { viewModel.handleVoiceInput(command) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = label,
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
