package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun OrbitalMicButton(
    isListening: Boolean,
    audioRms: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbital_mic_anim")

    // Outer Orbit Rotation (Clockwise)
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 2500 else 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_orbit"
    )

    // Inner Orbit Rotation (Counter-Clockwise)
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 3500 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_orbit"
    )

    // Pulsing Mic Core
    val micPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = if (isListening) 1.15f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 400 else 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_pulse"
    )

    val neonCyan = Color(0xFF00F0FF)
    val neonMagenta = Color(0xFFFF007F)
    val neonGold = Color(0xFFFFD700)

    val effectiveScale = micPulse + (audioRms * 0.35f)

    Box(
        modifier = modifier.size(150.dp),
        contentAlignment = Alignment.Center
    ) {
        // Multi-layered Cosmic Orbital Rings
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)

            // Layer 1: Outer Dashed Cosmic Ring
            val r1 = size.minDimension * 0.44f
            drawCircle(
                color = neonCyan.copy(alpha = 0.4f),
                radius = r1,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), outerRotation)
                )
            )

            // Layer 2: Inner Segmented Magenta Ring
            val r2 = size.minDimension * 0.36f
            drawCircle(
                color = neonMagenta.copy(alpha = 0.55f),
                radius = r2,
                center = center,
                style = Stroke(
                    width = 2.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(25f, 18f), innerRotation)
                )
            )

            // Orbiting Planetary Particles on Outer Ring
            val pCount = 4
            for (i in 0 until pCount) {
                val angle = (outerRotation + (i * 360f / pCount)) * (PI / 180f)
                val px = center.x + (r1 * cos(angle)).toFloat()
                val py = center.y + (r1 * sin(angle)).toFloat()
                drawCircle(
                    color = if (i % 2 == 0) neonCyan else neonGold,
                    radius = if (isListening) 4.5.dp.toPx() else 3.dp.toPx(),
                    center = Offset(px, py)
                )
            }

            // Orbiting Moon Particles on Inner Ring
            for (i in 0 until 3) {
                val angle = (innerRotation + (i * 120f)) * (PI / 180f)
                val px = center.x + (r2 * cos(angle)).toFloat()
                val py = center.y + (r2 * sin(angle)).toFloat()
                drawCircle(
                    color = neonMagenta,
                    radius = 3.5.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }

        // Central Glowing Core Button
        Box(
            modifier = Modifier
                .size(72.dp)
                .scale(effectiveScale)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = if (isListening) {
                            listOf(neonMagenta, Color(0xFF7928CA), Color(0xFF0A0F1D))
                        } else {
                            listOf(neonCyan, Color(0xFF0D1B2A), Color(0xFF070B14))
                        }
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = false, radius = 40.dp),
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                contentDescription = if (isListening) "Continuous Listening Active" else "Orbital Microphone",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}
