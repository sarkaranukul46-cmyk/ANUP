package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Iras3DAvatar(
    mood: IrasMood,
    isSpeaking: Boolean,
    isListening: Boolean,
    audioRms: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "iras_3d_anim")

    // 3D Floating Bobbing Motion
    val floatOffsetY by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float_offset"
    )

    // Gentle 3D Tilt / Breathing
    val tiltAngle by infiniteTransition.animateFloat(
        initialValue = -3.5f,
        targetValue = 3.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tilt_angle"
    )

    // Speaking Lip / Audio Reactive Pulse
    val speechPulse by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = if (isSpeaking) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking) 180 else 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "speech_pulse"
    )

    // Holographic Scanline Y
    val scanlineY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline_y"
    )

    // Orbital Halo Rotation
    val haloRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "halo_rotation"
    )

    val auraPrimary = when (mood) {
        IrasMood.HAPPY -> Color(0xFF00FF9D)
        IrasMood.SAD -> Color(0xFF00C2FF)
        IrasMood.ANGRY -> Color(0xFFFF0055)
        IrasMood.LISTENING -> Color(0xFF00F0FF)
        IrasMood.SPEAKING -> Color(0xFFFF007F)
        IrasMood.NEUTRAL -> Color(0xFF00F0FF)
    }

    val auraSecondary = when (mood) {
        IrasMood.HAPPY -> Color(0xFF00F0FF)
        IrasMood.SAD -> Color(0xFF7928CA)
        IrasMood.ANGRY -> Color(0xFFFF8800)
        IrasMood.LISTENING -> Color(0xFFFF007F)
        IrasMood.SPEAKING -> Color(0xFF7928CA)
        IrasMood.NEUTRAL -> Color(0xFFFF007F)
    }

    val rmsBoost = (audioRms * 0.25f)

    Box(
        modifier = modifier
            .size(310.dp)
            .graphicsLayer {
                rotationZ = tiltAngle
                rotationY = tiltAngle * 1.5f
                cameraDistance = 12f * density
            }
            .offset { IntOffset(0, floatOffsetY.toInt()) },
        contentAlignment = Alignment.Center
    ) {
        // Holographic Cybernetic Aura Glow
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = (size.minDimension / 2.2f) * (speechPulse + rmsBoost)

            // Outer Radial Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        auraPrimary.copy(alpha = 0.45f),
                        auraSecondary.copy(alpha = 0.2f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * 1.35f
                ),
                radius = radius * 1.35f,
                center = center
            )

            // Revolving Cybernetic Segmented Rings
            val ringRadius = radius * 1.08f
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        auraPrimary,
                        Color.Transparent,
                        auraSecondary,
                        Color.Transparent,
                        auraPrimary
                    )
                ),
                radius = ringRadius,
                center = center,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Orbiting data particles
            val particleCount = 8
            for (i in 0 until particleCount) {
                val angle = (haloRotation + (i * 360f / particleCount)) * (PI / 180f)
                val px = center.x + (ringRadius * cos(angle)).toFloat()
                val py = center.y + (ringRadius * sin(angle)).toFloat()
                drawCircle(
                    color = if (i % 2 == 0) auraPrimary else auraSecondary,
                    radius = if (i % 2 == 0) 4.5.dp.toPx() else 3.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }

        // 3D Avatar Image with Hologram effect
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(speechPulse + rmsBoost)
                .clip(CircleShape)
                .border(
                    width = 2.5.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(auraPrimary, auraSecondary, auraPrimary)
                    ),
                    shape = CircleShape
                )
                .background(Color(0xFF070B14))
        ) {
            Image(
                painter = painterResource(id = R.drawable.iras_avatar_3d),
                contentDescription = "IRAS 3D Character",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        drawContent()
                        // Holographic scanline sweep
                        val scanY = size.height * scanlineY
                        drawLine(
                            color = auraPrimary.copy(alpha = 0.5f),
                            start = Offset(0f, scanY),
                            end = Offset(size.width, scanY),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
            )
        }

        // Cyberpunk HUD Hexagon Badge over Avatar Base
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 8.dp)
                .background(
                    color = Color(0xDD0A0F1D),
                    shape = RoundedCornerShape(12.dp)
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(listOf(auraPrimary, auraSecondary)),
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            val statusText = when {
                isSpeaking -> "● IRAS SPEAKING"
                isListening -> "● LISTENING..."
                else -> "● IRAS AI ONLINE"
            }
            androidx.compose.material3.Text(
                text = statusText,
                color = auraPrimary,
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
        }
    }
}
