package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.service.GeminiService
import com.example.service.IrasBackgroundService
import com.example.service.SystemActionHandler
import com.example.service.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class IrasMood {
    HAPPY,
    SAD,
    ANGRY,
    NEUTRAL,
    LISTENING,
    SPEAKING
}

data class IrasUiState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val mood: IrasMood = IrasMood.NEUTRAL,
    val lastSpokenText: String = "আইরাস সবসময় সক্রিয়...",
    val transcript: String = "",
    val audioRms: Float = 0f,
    val isBackgroundServiceActive: Boolean = true,
    val systemStatus: String = "All Systems Online • Samsung Galaxy M51"
)

class IrasViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(IrasUiState())
    val uiState: StateFlow<IrasUiState> = _uiState.asStateFlow()

    private var voiceEngine: VoiceEngine? = null

    init {
        initVoiceEngine()
        startBackgroundService()
    }

    private fun initVoiceEngine() {
        voiceEngine = VoiceEngine(
            context = getApplication(),
            onSpeechRecognizedCallback = { text -> handleVoiceInput(text) },
            onListeningStateChangedCallback = { listening ->
                _uiState.value = _uiState.value.copy(
                    isListening = listening,
                    mood = if (listening) IrasMood.LISTENING else if (_uiState.value.isSpeaking) IrasMood.SPEAKING else IrasMood.NEUTRAL
                )
            },
            onRmsChangedCallback = { rms ->
                _uiState.value = _uiState.value.copy(audioRms = rms)
            },
            onSpeakingStateChangedCallback = { speaking ->
                _uiState.value = _uiState.value.copy(
                    isSpeaking = speaking,
                    mood = if (speaking) IrasMood.SPEAKING else if (_uiState.value.isListening) IrasMood.LISTENING else IrasMood.NEUTRAL
                )
            }
        )
    }

    fun startListening() {
        voiceEngine?.startListening()
    }

    fun stopListening() {
        voiceEngine?.stopListening()
    }

    fun toggleListening() {
        if (_uiState.value.isListening) {
            stopListening()
        } else {
            startListening()
        }
    }

    fun speak(text: String) {
        _uiState.value = _uiState.value.copy(lastSpokenText = text)
        voiceEngine?.speak(text)
    }

    fun handleVoiceInput(rawInput: String) {
        val input = rawInput.trim()
        if (input.isBlank()) return

        _uiState.value = _uiState.value.copy(transcript = input)

        val lower = input.lowercase()
        val context = getApplication<Application>().applicationContext

        // Evaluate Mood from input tone
        val detectedMood = when {
            lower.contains("খুশি") || lower.contains("ভাল") || lower.contains("happy") || lower.contains("love") || lower.contains("সুন্দর") -> IrasMood.HAPPY
            lower.contains("দুঃখ") || lower.contains("মন খারাপ") || lower.contains("sad") || lower.contains("কান্না") || lower.contains("কষ্ট") -> IrasMood.SAD
            lower.contains("রাগ") || lower.contains("angry") || lower.contains("বাজে") || lower.contains("মারব") || lower.contains("ঝগড়া") -> IrasMood.ANGRY
            else -> IrasMood.NEUTRAL
        }

        viewModelScope.launch {
            when {
                // Phone calls
                lower.contains("ফোন") || lower.contains("কল") || lower.contains("call") || lower.contains("dial") -> {
                    val response = SystemActionHandler.makePhoneCall(context, input)
                    speak(response)
                }

                // Flashlight / Torch
                lower.contains("টর্চ জ্বালা") || lower.contains("টর্চ অন") || lower.contains("flashlight on") || lower.contains("torch on") -> {
                    val response = SystemActionHandler.toggleTorch(context, true)
                    speak(response)
                }
                lower.contains("টর্চ বন্ধ") || lower.contains("টর্চ অফ") || lower.contains("টর্চ নিভা") || lower.contains("flashlight off") || lower.contains("torch off") -> {
                    val response = SystemActionHandler.toggleTorch(context, false)
                    speak(response)
                }
                lower.contains("টর্চ") || lower.contains("flashlight") || lower.contains("torch") -> {
                    val nextState = !SystemActionHandler.isTorchOn
                    val response = SystemActionHandler.toggleTorch(context, nextState)
                    speak(response)
                }

                // Accessibility Automated Actions (Home, Back, Notifications, Quick Settings, Lock, Screenshot)
                lower.contains("হোমে যাও") || lower.contains("হোম স্ক্রিন") || lower.contains("go home") || lower == "হোম" -> {
                    val response = SystemActionHandler.performAccessibilityAction(context, "home")
                    speak(response)
                }
                lower.contains("পিছনে যাও") || lower.contains("ব্যাক কর") || lower.contains("go back") || lower == "ব্যাক" -> {
                    val response = SystemActionHandler.performAccessibilityAction(context, "back")
                    speak(response)
                }
                lower.contains("নোটিফিকেশন দেখাও") || lower.contains("নোটিফিকেশন নামাও") || lower.contains("show notification") -> {
                    val response = SystemActionHandler.performAccessibilityAction(context, "notifications")
                    speak(response)
                }
                lower.contains("কুইক সেটিংস") || lower.contains("কন্ট্রোল সেন্টার") || lower.contains("quick settings") -> {
                    val response = SystemActionHandler.performAccessibilityAction(context, "quick_settings")
                    speak(response)
                }
                lower.contains("স্ক্রিন লক") || lower.contains("ফোন লক") || lower.contains("lock screen") -> {
                    val response = SystemActionHandler.performAccessibilityAction(context, "lock")
                    speak(response)
                }
                lower.contains("স্ক্রিনশট") || lower.contains("screenshot") -> {
                    val response = SystemActionHandler.performAccessibilityAction(context, "screenshot")
                    speak(response)
                }

                // Notification & Accessibility Settings Access
                lower.contains("নোটিফিকেশন") || lower.contains("notification") -> {
                    val response = SystemActionHandler.openSettings(context, "notification_listener")
                    speak(response)
                }
                lower.contains("এক্সেসিবিলিটি") || lower.contains("accessibility") -> {
                    val response = SystemActionHandler.openSettings(context, "accessibility")
                    speak(response)
                }

                // Music & YouTube
                lower.contains("গান") || lower.contains("বাজা") || lower.contains("চালা") || lower.contains("song") || lower.contains("music") -> {
                    val response = SystemActionHandler.playMusicOnYoutube(context, input)
                    speak(response)
                }

                // WhatsApp message
                lower.contains("হোয়াটসঅ্যাপ") && (lower.contains("মেসেজ") || lower.contains("বল") || lower.contains("message")) -> {
                    val response = SystemActionHandler.sendWhatsappMessage(context, input, "Hello from IRAS Voice Assistant!")
                    speak(response)
                }

                // Apps
                lower.contains("খোল") || lower.contains("open") || lower.contains("লঞ্চ") || lower.contains("স্টার্ট") -> {
                    val response = SystemActionHandler.launchApp(context, input)
                    speak(response)
                }

                // Volume
                lower.contains("ভলিউম বাড়া") || lower.contains("volume up") -> {
                    val response = SystemActionHandler.adjustVolume(context, true)
                    speak(response)
                }
                lower.contains("ভলিউম কমা") || lower.contains("volume down") -> {
                    val response = SystemActionHandler.adjustVolume(context, false)
                    speak(response)
                }

                // Battery
                lower.contains("ব্যাটারি") || lower.contains("battery") || lower.contains("চার্জ") -> {
                    val response = SystemActionHandler.getBatteryStatus(context)
                    speak(response)
                }

                // Alarm
                lower.contains("অ্যালার্ম") || lower.contains("alarm") -> {
                    val response = SystemActionHandler.setAlarm(context, 6, 0, "IRAS Morning Alarm")
                    speak(response)
                }

                // SOS Help
                lower.contains("হেল্প") || lower.contains("help") || lower.contains("sos") || lower.contains("বাঁচাও") -> {
                    val response = SystemActionHandler.sendSos(context)
                    speak(response)
                }

                // Sensor & Device Info
                lower.contains("তাপমাত্রা") || lower.contains("সেন্সর") || lower.contains("মেমোরি") || lower.contains("স্টোরেজ") || lower.contains("device") -> {
                    val response = SystemActionHandler.getDeviceSensorInfo(context)
                    speak(response)
                }

                // Wifi / Bluetooth Settings
                lower.contains("ওয়াইফাই") || lower.contains("wifi") -> {
                    val response = SystemActionHandler.openSettings(context, "wifi")
                    speak(response)
                }
                lower.contains("ব্লুটুথ") || lower.contains("bluetooth") -> {
                    val response = SystemActionHandler.openSettings(context, "bluetooth")
                    speak(response)
                }

                // Greetings / Mood Q&A
                lower.contains("কেমন আছো") || lower.contains("how are you") || lower.contains("kaisa hai") -> {
                    val greeting = "হাঁ ভাইয়া, bilkul mast hu! আপনি কেমন আছেন? Your 3D AI Assistant is fully charged!"
                    _uiState.value = _uiState.value.copy(mood = IrasMood.HAPPY)
                    speak(greeting)
                }

                // Fallback to Gemini 3.7 / 2.5 Flash API for high-IQ intelligence
                else -> {
                    _uiState.value = _uiState.value.copy(mood = detectedMood)
                    val geminiAnswer = GeminiService.askGemini(input)
                    speak(geminiAnswer)
                }
            }
        }
    }

    fun setManualMood(mood: IrasMood) {
        _uiState.value = _uiState.value.copy(mood = mood)
        val text = when (mood) {
            IrasMood.HAPPY -> "ভাইয়া, আজ মনটা খুব সুন্দর আর আনন্দিত!"
            IrasMood.SAD -> "কী হলো ভাইয়া, কোনো টেনশন? আমি তো সবসময় আপনার সাথে আছি।"
            IrasMood.ANGRY -> "অল সিস্টেমস অন রেড অ্যালার্ট! কেউ ঝামেলা করলে আমাকে বলবেন!"
            else -> "আইরাস নরমাল মোডে রেডি।"
        }
        speak(text)
    }

    private fun startBackgroundService() {
        val context = getApplication<Application>().applicationContext
        try {
            val serviceIntent = Intent(context, IrasBackgroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine?.shutdown()
    }
}
