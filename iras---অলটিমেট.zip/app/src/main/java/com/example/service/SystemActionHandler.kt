package com.example.service

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.widget.Toast
import com.example.data.ContactsData
import java.net.URLEncoder

object SystemActionHandler {

    var isTorchOn: Boolean = false
        private set

    fun makePhoneCall(context: Context, contactQuery: String): String {
        val contact = ContactsData.findContact(contactQuery)
        val phoneNumber = contact?.phone ?: extractPhoneNumber(contactQuery)

        return if (!phoneNumber.isNullOrBlank()) {
            val displayName = contact?.banglaName ?: phoneNumber
            try {
                val callIntent = Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$phoneNumber")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(callIntent)
                "হাঁ ভাইয়া, $displayName কে কল করছি।"
            } catch (e: SecurityException) {
                val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:$phoneNumber")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(dialIntent)
                "$displayName এর নম্বরে ডায়াল স্ক্রিন ওপেন করেছি।"
            } catch (e: Exception) {
                "কল করা গেল না ভাইয়া।"
            }
        } else {
            "নাম্বার খুঁজে পেলাম না ভাইয়া।"
        }
    }

    private fun extractPhoneNumber(query: String): String? {
        val regex = Regex("\\d{10,12}")
        return regex.find(query)?.value
    }

    fun toggleTorch(context: Context, turnOn: Boolean): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var selectedId: String? = null
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val isBack = characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                if (hasFlash && isBack) {
                    selectedId = id
                    break
                }
            }
            if (selectedId == null) {
                selectedId = cameraManager.cameraIdList.firstOrNull { id ->
                    cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
            }

            if (selectedId != null) {
                cameraManager.setTorchMode(selectedId, turnOn)
                isTorchOn = turnOn
                if (turnOn) "টর্চ অন করা হয়েছে, ফ্ল্যাশলাইট সক্রিয়!" else "টর্চ অফ করা হয়েছে।"
            } else {
                "ফ্ল্যাশলাইট সাপোর্ট পাওয়া যায়নি।"
            }
        } catch (e: Exception) {
            "ফ্ল্যাশলাইট কন্ট্রোল ব্যর্থ হয়েছে।"
        }
    }

    fun playMusicOnYoutube(context: Context, songQuery: String): String {
        val cleanSong = songQuery
            .replace("গান বাজা", "")
            .replace("গান চালা", "")
            .replace("গান", "")
            .replace("বাজা", "")
            .replace("চালা", "")
            .replace("ইউটিউবে", "")
            .replace("play", "")
            .trim()

        val searchQuery = if (cleanSong.isBlank()) "popular bengali songs" else cleanSong
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(searchQuery, "UTF-8"))
                setPackage("com.google.android.youtube")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "ইউটিউবে $searchQuery চালু করছি ভাইয়া!"
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(searchQuery, "UTF-8"))).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            "গান শুরু করছি।"
        }
    }

    fun launchApp(context: Context, appName: String): String {
        val lower = appName.lowercase()
        val packageName = when {
            lower.contains("ফ্রিফায়ার") || lower.contains("free fire") || lower.contains("freefire") -> "com.dts.freefiremax"
            lower.contains("হোয়াটসঅ্যাপ") || lower.contains("whatsapp") -> "com.whatsapp"
            lower.contains("ইউটিউব") || lower.contains("youtube") -> "com.google.android.youtube"
            lower.contains("ফেসবুক") || lower.contains("facebook") -> "com.facebook.katana"
            lower.contains("ক্যালকুলেটর") || lower.contains("calculator") -> "com.sec.android.app.popupcalculator"
            lower.contains("ক্যামেরা") || lower.contains("camera") || lower.contains("ফটো") -> "camera"
            lower.contains("ফাইল") || lower.contains("files") || lower.contains("ডাউনলোড") -> "files"
            lower.contains("ক্রোম") || lower.contains("chrome") -> "com.android.chrome"
            else -> null
        }

        if (packageName == "camera") {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(intent)
                "ক্যামেরা ওপেন করেছি ভাইয়া!"
            } catch (e: Exception) { "ক্যামেরা ওপেন করা গেল না।" }
        }

        if (packageName == "files") {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(intent)
                "ফাইল ম্যানেজার ওপেন করেছি।"
            } catch (e: Exception) { "ফাইল ওপেন করা গেল না।" }
        }

        if (packageName != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return "অ্যাপ ওপেন করছি ভাইয়া!"
            }
        }

        val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$appName")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(searchIntent)
            "অ্যাপ সার্চ করছি।"
        } catch (e: Exception) {
            "অ্যাপ পাওয়া যায়নি ভাইয়া।"
        }
    }

    fun adjustVolume(context: Context, increase: Boolean): String {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return if (increase) "ভলিউম বাড়িয়ে দিলাম ভাইয়া!" else "ভলিউম কমিয়ে দিয়েছি।"
    }

    fun getBatteryStatus(context: Context): String {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 75
        val chargeText = if (isCharging) "এবং চার্জ হচ্ছে" else "এখন ব্যাটারিতে চলছে"
        return "ভাইয়া, আপনার ফোনের ব্যাটারি $batteryPct% আছে, $chargeText।"
    }

    fun setAlarm(context: Context, hour: Int, minute: Int, message: String = "IRAS Alarm"): String {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "অ্যালার্ম সেট করে দিয়েছি ভাইয়া!"
        } catch (e: Exception) {
            "অ্যালার্ম সেট করা গেল না।"
        }
    }

    fun sendWhatsappMessage(context: Context, contactQuery: String, message: String): String {
        val contact = ContactsData.findContact(contactQuery)
        val phone = contact?.phone ?: extractPhoneNumber(contactQuery)
        return if (!phone.isNullOrBlank()) {
            val formattedPhone = if (phone.startsWith("+")) phone else "+91$phone"
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=" + URLEncoder.encode(message, "UTF-8"))
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "${contact?.banglaName ?: phone} কে মেসেজ পাঠানো হচ্ছে।"
            } catch (e: Exception) {
                "হোয়াটসঅ্যাপ খোলা যায়নি।"
            }
        } else {
            "কাকে মেসেজ পাঠাবেন বলুন ভাইয়া।"
        }
    }

    fun sendSos(context: Context): String {
        val emergencyContact = ContactsData.contacts.first() // Baba
        try {
            toggleTorch(context, true)
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager?.sendTextMessage(
                emergencyContact.phone,
                null,
                "EMERGENCY SOS: Please help me! Location alert triggered by IRAS.",
                null,
                null
            )
            makePhoneCall(context, emergencyContact.name)
            return "এসওএস অ্যাক্টিভেট হয়েছে! ${emergencyContact.banglaName} কে কল ও মেসেজ পাঠানো হয়েছে এবং ফ্ল্যাশলাইট অন করা হয়েছে।"
        } catch (e: Exception) {
            return "এসওএস সক্রিয় করা হয়েছে।"
        }
    }

    fun getDeviceSensorInfo(context: Context): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        val bytesAvailable = stat.availableBlocksLong * stat.blockSizeLong
        val gigAvailable = bytesAvailable / (1024 * 1024 * 1024)
        return "Samsung Galaxy M51 সিস্টেম স্বাভাবিক আছে। স্টোরেজ $gigAvailable GB খালি আছে, ওয়ান ইউআই কোর ৪.১ স্মুথ চলছে!"
    }

    fun openSettings(context: Context, type: String): String {
        val intent = when (type) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "notification_listener" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "dnd" -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

        return try {
            context.startActivity(intent)
            "$type সেটিংস ওপেন করেছি ভাইয়া।"
        } catch (e: Exception) {
            "সেটিংস খোলা গেল না।"
        }
    }

    fun performAccessibilityAction(context: Context, actionType: String): String {
        if (!IrasAccessibilityService.isServiceActive) {
            openSettings(context, "accessibility")
            return "অ্যাক্সেসিবিলিটি সার্ভিস সক্রিয় করতে সেটিংসে নিয়ে যাচ্ছি ভাইয়া। অন করে দিন।"
        }
        val success = when (actionType) {
            "home" -> IrasAccessibilityService.performHome()
            "back" -> IrasAccessibilityService.performBack()
            "notifications" -> IrasAccessibilityService.performNotifications()
            "quick_settings" -> IrasAccessibilityService.performQuickSettings()
            "lock" -> IrasAccessibilityService.performLockScreen()
            "screenshot" -> IrasAccessibilityService.performScreenshot()
            else -> false
        }
        return if (success) {
            when (actionType) {
                "home" -> "হোম স্ক্রিনে চলে এসেছি ভাইয়া!"
                "back" -> "ব্যাক করা হয়েছে।"
                "notifications" -> "নোটিফিকেশন প্যানেল খুলেছি।"
                "quick_settings" -> "কুইক সেটিংস ওপেন করেছি।"
                "lock" -> "স্ক্রিন লক করা হয়েছে।"
                "screenshot" -> "স্ক্রিনশট নেওয়া হয়েছে ভাইয়া।"
                else -> "অ্যাকশন সম্পন্ন হয়েছে।"
            }
        } else {
            "অ্যাকশন সম্পন্ন করা যায়নি ভাইয়া।"
        }
    }
}
