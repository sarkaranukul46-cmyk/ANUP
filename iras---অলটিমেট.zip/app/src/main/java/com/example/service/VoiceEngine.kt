package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceEngine(
    private val context: Context,
    private val onSpeechRecognizedCallback: (String) -> Unit,
    private val onListeningStateChangedCallback: (Boolean) -> Unit,
    private val onRmsChangedCallback: (Float) -> Unit,
    private val onSpeakingStateChangedCallback: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsReady = false
    private var isContinuous = true
    private val mainHandler = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(context, this)
        initRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            // Prefer Bengali or Hindi or English with sweet higher pitch
            val banglaLocale = Locale("bn", "BD")
            val hindiLocale = Locale("hi", "IN")
            val englishLocale = Locale("en", "IN")

            if (tts?.isLanguageAvailable(banglaLocale) == TextToSpeech.LANG_AVAILABLE) {
                tts?.language = banglaLocale
            } else if (tts?.isLanguageAvailable(hindiLocale) == TextToSpeech.LANG_AVAILABLE) {
                tts?.language = hindiLocale
            } else {
                tts?.language = englishLocale
            }

            tts?.setPitch(1.35f) // Sweet female tone
            tts?.setSpeechRate(1.05f) // Energetic and smooth

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post { onSpeakingStateChangedCallback(true) }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post {
                        onSpeakingStateChangedCallback(false)
                        if (isContinuous) {
                            startListening()
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mainHandler.post { onSpeakingStateChangedCallback(false) }
                }
            })
        }
    }

    private fun initRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        onListeningStateChangedCallback(true)
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        onRmsChangedCallback(normalized)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        onListeningStateChangedCallback(false)
                    }

                    override fun onError(error: Int) {
                        onListeningStateChangedCallback(false)
                        // If continuous, restart after a brief delay to prevent tight error loops
                        if (isContinuous) {
                            mainHandler.postDelayed({
                                startListening()
                            }, 1000)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull() ?: ""
                        if (spokenText.isNotBlank()) {
                            onSpeechRecognizedCallback(spokenText)
                        } else if (isContinuous) {
                            startListening()
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull() ?: ""
                        if (spokenText.isNotBlank()) {
                            onRmsChangedCallback(0.7f)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-IN")
                putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("bn-IN", "hi-IN", "en-US"))
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            onListeningStateChangedCallback(false)
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {}
        onListeningStateChangedCallback(false)
    }

    fun speak(text: String) {
        if (!isTtsReady || text.isBlank()) return
        stopListening()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "IRAS_VOICE_${System.currentTimeMillis()}")
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "IRAS_VOICE_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
        onSpeakingStateChangedCallback(false)
    }

    fun shutdown() {
        mainHandler.removeCallbacksAndMessages(null)
        stopSpeaking()
        stopListening()
        speechRecognizer?.destroy()
        tts?.shutdown()
    }
}
