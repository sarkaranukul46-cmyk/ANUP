package com.example.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IrasNotificationService : NotificationListenerService() {

    companion object {
        var lastNotificationTitle: String = ""
        var lastNotificationText: String = ""
        var onNotificationReceived: ((title: String, text: String) -> Unit)? = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        val extras = sbn?.notification?.extras ?: return
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        if (title.isNotBlank() && text.isNotBlank() && !sbn.packageName.contains("example")) {
            lastNotificationTitle = title
            lastNotificationText = text
            onNotificationReceived?.invoke(title, text)
        }
    }
}
