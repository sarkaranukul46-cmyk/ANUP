package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class IrasBackgroundService : Service() {

    companion object {
        const val CHANNEL_ID = "iras_bg_service_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "ACTION_START_CONTINUOUS_LISTENING"
        const val ACTION_STOP = "ACTION_STOP_CONTINUOUS_LISTENING"
        var isServiceRunning = false
            private set

        fun startContinuousService(context: Context) {
            val intent = Intent(context, IrasBackgroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopContinuousService(context: Context) {
            val intent = Intent(context, IrasBackgroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private var voiceEngine: VoiceEngine? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "IRAS::ContinuousListeningWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(24 * 60 * 60 * 1000L) // 24 hours lock
            }
        } catch (e: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(true)
            stopSelf()
            isServiceRunning = false
            return START_NOT_STICKY
        }

        isServiceRunning = true
        try {
            val notification = createNotification("আইরাস অলটিমেট অ্যাক্টিভ - আপনার ভয়েস শুনছে...")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            try {
                startForeground(NOTIFICATION_ID, createNotification("আইরাস অ্যাক্টিভ"))
            } catch (e2: Exception) {}
        }

        initBackgroundVoice()

        return START_STICKY
    }

    private fun initBackgroundVoice() {
        if (voiceEngine != null) return

        voiceEngine = VoiceEngine(
            context = applicationContext,
            onSpeechRecognizedCallback = { spokenText ->
                updateNotification("শুনলাম: \"$spokenText\"")
                handleSpokenCommand(spokenText)
            },
            onListeningStateChangedCallback = { isListening ->
                if (isListening) {
                    updateNotification("মাইক্রোফোন অন: কমান্ড বলুন...")
                }
            },
            onRmsChangedCallback = { /* audio amplitude */ },
            onSpeakingStateChangedCallback = { isSpeaking ->
                if (isSpeaking) {
                    updateNotification("আইরাস কথা বলছে...")
                }
            }
        )

        mainHandler.postDelayed({
            voiceEngine?.startListening()
        }, 1000)
    }

    private fun handleSpokenCommand(input: String) {
        val lower = input.lowercase()
        when {
            lower.contains("টর্চ অন") || lower.contains("টর্চ জ্বালা") -> {
                val res = SystemActionHandler.toggleTorch(applicationContext, true)
                voiceEngine?.speak(res)
            }
            lower.contains("টর্চ অফ") || lower.contains("টর্চ বন্ধ") -> {
                val res = SystemActionHandler.toggleTorch(applicationContext, false)
                voiceEngine?.speak(res)
            }
            lower.contains("হোমে যাও") || lower == "হোম" -> {
                val res = SystemActionHandler.performAccessibilityAction(applicationContext, "home")
                voiceEngine?.speak(res)
            }
            lower.contains("ব্যাক") -> {
                val res = SystemActionHandler.performAccessibilityAction(applicationContext, "back")
                voiceEngine?.speak(res)
            }
            lower.contains("স্ক্রিনশট") -> {
                val res = SystemActionHandler.performAccessibilityAction(applicationContext, "screenshot")
                voiceEngine?.speak(res)
            }
            lower.contains("স্ক্রিন লক") || lower.contains("ফোন লক") -> {
                val res = SystemActionHandler.performAccessibilityAction(applicationContext, "lock")
                voiceEngine?.speak(res)
            }
            lower.contains("ফোন") || lower.contains("কল") -> {
                val res = SystemActionHandler.makePhoneCall(applicationContext, input)
                voiceEngine?.speak(res)
            }
            lower.contains("গান") || lower.contains("বাজা") -> {
                val res = SystemActionHandler.playMusicOnYoutube(applicationContext, input)
                voiceEngine?.speak(res)
            }
            lower.contains("ব্যাটারি") -> {
                val res = SystemActionHandler.getBatteryStatus(applicationContext)
                voiceEngine?.speak(res)
            }
            else -> {
                // Background short AI response
                val answer = "হাঁ ভাইয়া, $input কমান্ড পেয়েছি।"
                voiceEngine?.speak(answer)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "IRAS AI Continuous Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Continuous background microphone and voice assistant service"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(statusText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, IrasBackgroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("IRAS - সার্বক্ষণিক ভয়েস মোড সক্রিয়")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_iras_notification)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_iras_notification, "বন্ধ করুন", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(statusText: String) {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.notify(NOTIFICATION_ID, createNotification(statusText))
        } catch (e: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isServiceRunning = false
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {}
        try {
            voiceEngine?.shutdown()
        } catch (e: Exception) {}
        serviceScope.cancel()
        super.onDestroy()
    }
}
