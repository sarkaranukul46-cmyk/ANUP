package com.example.data

data class ContactItem(
    val name: String,
    val banglaName: String,
    val phone: String,
    val aliases: List<String>
)

object ContactsData {
    val contacts = listOf(
        ContactItem("Baba", "বাবা", "6296825861", listOf("বাবা", "বাবাকে", "baba", "father", "dad")),
        ContactItem("Bapi Dada", "বাপি দাদা", "6295298426", listOf("বাপি দাদা", "বাপি", "bapi dada", "bapi")),
        ContactItem("Biltu Kaka", "বিল্টু কাকা", "9046948298", listOf("বিল্টু কাকা", "বিল্টু", "biltu kaka", "biltu")),
        ContactItem("Boro Jethi", "বড় জেঠি", "6294785010", listOf("বড় জেঠি", "জেঠি", "boro jethi", "jethi")),
        ContactItem("Chinu Mama", "চিনু মামা", "6362566570", listOf("চিনু মামা", "চিনু", "chinu mama", "chinu")),
        ContactItem("Choto Pisi", "ছোট পিসি", "9548313930", listOf("ছোট পিসি", "পিসি", "choto pisi", "pisi")),
        ContactItem("Choto Biyai", "ছোট বিয়াই", "9749151704", listOf("ছোট বিয়াই", "বিয়াই", "choto biyai", "biyai")),
        ContactItem("Choto Didi", "ছোট দিদি", "9749904234", listOf("ছোট দিদি", "choto didi")),
        ContactItem("Deb Jiju", "দেব জিজু", "9832558016", listOf("দেব জিজু", "দেব", "deb jiju", "deb")),
        ContactItem("Dida", "দিদা", "9933596639", listOf("দিদা", "দিদু", "dida", "grandmother")),
        ContactItem("Dida 2", "দিদা2", "9051664232", listOf("দিদা ২", "দিদা2", "dida 2")),
        ContactItem("Gokul Sarkar", "গোকুল সরকার", "9382508292", listOf("গোকুল সরকার", "গোকুল", "gokul sarkar", "gokul")),
        ContactItem("Koyel Didi", "কয়েল দিদি", "8167024996", listOf("কয়েল দিদি", "কয়েল", "koyel didi", "koyel")),
        ContactItem("Kutta", "কুত্তা", "7602911256", listOf("কুত্তা", "kutta")),
        ContactItem("Kaka", "কাকা", "9932583345", listOf("কাকা", "kaka", "uncle")),
        ContactItem("Mia Bhai", "মিয়া ভাই", "7811024560", listOf("মিয়া ভাই", "মিয়া", "mia bhai")),
        ContactItem("Milan Dosto", "মিলন দোস্ত", "7478923624", listOf("মিলন দোস্ত", "মিলন", "milan dosto", "milan")),
        ContactItem("Mona 2", "মনা2", "8653122955", listOf("মনা ২", "মনা2", "mona 2")),
        ContactItem("Mona 3", "মনা3", "9239728709", listOf("মনা ৩", "মনা3", "mona 3")),
        ContactItem("Mona Didi", "মনা দিদি", "8918335299", listOf("মনা দিদি", "mona didi")),
        ContactItem("Nandu", "নন্দু", "9083376437", listOf("নন্দু", "nandu")),
        ContactItem("Papiya", "পাপিয়া", "8944828371", listOf("পাপিয়া", "papiya")),
        ContactItem("Puja Didi", "পূজা দিদি", "9874845290", listOf("পূজা দিদি", "পূজা", "puja didi", "puja")),
        ContactItem("Rahul", "রাহুল", "8107007629", listOf("রাহুল", "রাহুলকে", "rahul")),
        ContactItem("Raj Bondhu", "রাজ বন্ধু", "8250861863", listOf("রাজ বন্ধু", "রাজ", "raj bondhu", "raj")),
        ContactItem("Samrat", "সম্রাট", "7001166912", listOf("সম্রাট", "samrat")),
        ContactItem("Boro Didi", "বড় দিদি", "9038816004", listOf("বড় দিদি", "boro didi")),
        ContactItem("Sourav", "সৌরভ", "7001727481", listOf("সৌরভ", "sourav")),
        ContactItem("Subho Noob", "শুভ নুব", "7908156278", listOf("শুভ নুব", "subho noob")),
        ContactItem("Farakka", "ফারাক্কা", "6287834738", listOf("ফারাক্কা", "farakka")),
        ContactItem("Suraj", "সুরাজ", "8250952485", listOf("সুরাজ", "suraj")),
        ContactItem("Subhankar", "শুভঙ্কর", "9732164629", listOf("শুভঙ্কর", "subhankar")),
        ContactItem("Subhajit", "শুভজিৎ", "7074053010", listOf("শুভজিৎ", "subhajit")),
        ContactItem("Toto", "টোটো", "6294883501", listOf("টোটো", "toto")),
        ContactItem("Angshu", "অংশু", "7501333094", listOf("অংশু", "angshu")),
        ContactItem("Bhaipo", "ভাইপো", "9800082242", listOf("ভাইপো", "bhaipo")),
        ContactItem("Jatin", "যতীন", "8158001784", listOf("যতীন", "jatin")),
        ContactItem("Leli", "লেলি", "9635727836", listOf("লেলি", "leli")),
        ContactItem("Kak", "কাক", "9749808139", listOf("কাক", "kak")),
        ContactItem("Sudhir", "সুধীর", "9382288912", listOf("সুধীর", "sudhir"))
    )

    fun findContact(query: String): ContactItem? {
        val clean = query.lowercase().trim()
        return contacts.firstOrNull { contact ->
            contact.aliases.any { clean.contains(it.lowercase()) } ||
                    contact.name.lowercase().contains(clean) ||
                    contact.banglaName.contains(clean)
        }
    }
}
